# Classic Arcade Game Clone Project
It's a classic game. In this game you have a Player and Enemies (Bugs). However, the player should reach the lake without hitting the bugs.

## Table of Contents

- [Instructions](#instructions)

-In this game you have a Player and Enemies (Bugs). The goal of the game the player must be reach the lake without hitting into any one of the enemies.
-To start the game, use the buttons in keybord such as, move, left, right, up and down. 
-The enemies move in varying speeds on the paved block portion of the scene. Once the player hit with an enemy, he lose and moves back to the start square and be in same level with Alert Message display. 
  Once the player reaches the water he wins and move to the next level and the score will increase.
- When something occurs like the player hitting the bugs or the player reach the lack and win , a sound effect is played .


## Sound Library
1- `won.wav`: [Collect items](https://freesound.org/people/Higgs01/sounds/430925/)
2- `collision.wav`: [Collect items](https://freesound.org/people/noirenex/sounds/159408/)


