//sound file effect 
const soundFiles = {
    won: new Audio(`audio/won.wav`), // Credits: https://freesound.org/people/Higgs01/sounds/430925/
    collision: new Audio(`audio/collision.wav`) // Credits: https://freesound.org/people/noirenex/sounds/159408/
  };
// Enemies our player must avoid
var Enemy = function Enemy(x, y) {
    // Variables applied to each of our instances go here,
    // we've provided one for you to get started
    // The image/sprite for our enemies, this uses
    // a helper we've provided to easily load images
    this.x = x;
    this.y = y;
    this.sprite = 'images/enemy-bug.png';
    this.speed = getRandomInt(200, 100);
};
// Update the enemy's position, required method for game
// Parameter: dt, a time delta between ticks
Enemy.prototype.update = function(dt) {
    // You should multiply any movement by the dt parameter
    // which will ensure the game runs at the same speed for
    // all computers.
    //**************** */
    //Update the enemy movement speed
    this.x += this.speed * dt;
    if (this.x > 505) {
        this.x = -150;
        this.speed = getRandomInt(200, 100);
    }
    this.checkCollision(); // invoke the callision function 
};
// Draw the enemy on the screen, required method for game
Enemy.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

Enemy.prototype.handleInput = function(dt) {};

// function to check the collision between the player and bugs with sound effect and alert MESS
Enemy.prototype.checkCollision = function() 
{
        if (player.y + 131 >= this.y + 90 &&
            player.y + 73 <= this.y + 135 &&
            player.x + 25 <= this.x + 88 &&
            player.x + 76 >= this.x + 11) 
        {
            alert("Be Careful !! and Try Again");
            soundFiles.collision.play();
            reset();
        };
};
// Now write your own player class
// This class requires an update(), render() and
// a handleInput() method.
function Player() {
    // render the charcter
    this.sprite = 'images/char-boy.png';
    // sets right and left movement
    this.rightLeft = 101;
    // sets up and down movement
    this.upDown = 83;
    // sets initial player position
    this.x = 2 * this.rightLeft;
    this.y = 4 * this.upDown + 54;
    this.level = 1;
    this.Win = 0;
}
Player.prototype.update = function(dt) {
};
Player.prototype.render = function(dt) {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};
// this function to handle the input keys 
Player.prototype.handleInput = function(key) {
        
            if (key === 'left' && this.x > 0) {
                this.x -= this.rightLeft;
            }
            if (key === 'right' && this.x < 4 * this.rightLeft) {
                this.x += this.rightLeft;
            }
            if (key === 'up' && this.y > -85) {
                this.y = this.y - 80;
                this.win();
            }
            if (key === 'down' && this.y < 4 * this.upDown) {
                this.y += this.upDown;
            }
    };
// win function invock when the player reach the lake the the level and score will increse and sound effect play 
Player.prototype.win = function() {
    setTimeout(() => {
        if (this.y <= -10) {
            this.level ++;
            document.getElementById('level').innerHTML = `Level: ${this.level}`;
            this.Win += 1;
            document.getElementById('Win').innerHTML = `Win: ${this.Win}`;
            soundFiles.won.play();// Play won sound effect
            reset();
        }
    }, 300);
};
// a rest function it will invocked when player win or loose
function reset() {
    this.rightLeft = 101;
    this.upDown = 83;
    player.x = 2 * this.rightLeft;
    player.y = 4 * this.upDown + 54;
};
// Now instantiate your objects.
// Place all enemy objects in an array called allEnemies
// Place the player object in a variable called player
// create the enemys
  var allEnemies = [];
  for(let i = 0; i < 3; i++) {
    let enemy = new Enemy(-300 , 40 + i*90);
    allEnemies.push(enemy);
  }
//create a player object from constructor function 
let player = new Player();
// This listens for key presses and sends the keys to your
// Player.handleInput() method. You don't need to modify this.
document.addEventListener('keyup', function(e) {
    var allowedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down'
    };
player.handleInput(allowedKeys[e.keyCode]);
});
function getRandomInt(min, max) 
{
    return Math.floor((Math.random() * (max - min + 1)) + min);
};
